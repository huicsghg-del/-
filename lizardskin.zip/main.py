import os
import uuid
import asyncio
import logging
from datetime import datetime, date, timedelta
from typing import Optional, List
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Depends, HTTPException, Request, Form, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import String, Integer, Float, Boolean, DateTime, Text, ForeignKey, select, func, or_
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, selectinload
from sqlalchemy.ext.asyncio import AsyncAttrs, create_async_engine, async_sessionmaker, AsyncSession
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# ==================== 配置（从环境变量读取） ====================
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "0").split(",") if x.strip().isdigit()]
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")
# 部署后会自动使用平台提供的域名，也可以手动设置
WEBAPP_URL = os.getenv("WEBAPP_URL", "")

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"
DATA_DIR.mkdir(exist_ok=True)
(STATIC_DIR / "gifts").mkdir(parents=True, exist_ok=True)

DATABASE_URL = f"sqlite+aiosqlite:///{DATA_DIR / 'gift_rental.db'}"

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ==================== 数据库模型 ====================
class Base(AsyncAttrs, DeclarativeBase):
    pass

class Gift(Base):
    __tablename__ = "gifts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    gift_number: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(100))
    variant: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    image_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    category: Mapped[str] = mapped_column(String(50), default="全部")
    background: Mapped[str] = mapped_column(String(50), default="全部")
    background_symbol: Mapped[str] = mapped_column(String(50), default="全部")
    price_per_day: Mapped[float] = mapped_column(Float, default=0.02)
    min_days: Mapped[int] = mapped_column(Integer, default=3)
    max_days: Mapped[int] = mapped_column(Integer, default=180)
    is_available: Mapped[bool] = mapped_column(Boolean, default=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    orders: Mapped[list["Order"]] = relationship("Order", back_populates="gift")

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    first_name: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    orders: Mapped[list["Order"]] = relationship("Order", back_populates="user")

class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    order_no: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    gift_id: Mapped[int] = mapped_column(ForeignKey("gifts.id"))
    days: Mapped[int] = mapped_column(Integer)
    price_per_day: Mapped[float] = mapped_column(Float)
    total_price: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    start_date: Mapped[Optional[date]] = mapped_column(nullable=True)
    end_date: Mapped[Optional[date]] = mapped_column(nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    user: Mapped["User"] = relationship("User", back_populates="orders")
    gift: Mapped["Gift"] = relationship("Gift", back_populates="orders")

engine = create_async_engine(DATABASE_URL, echo=False)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

async def get_session():
    async with async_session() as session:
        yield session

# ==================== Telegram Bot ====================
bot_app = None

async def bot_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    url = WEBAPP_URL or "https://example.com"
    keyboard = [[InlineKeyboardButton("🎁 打开礼物租赁", web_app=WebAppInfo(url=url))]]
    text = (
        f"你好 {user.first_name}！\n\n"
        "欢迎使用礼物租赁机器人。\n"
        "点击下方按钮打开租赁页面。"
    )
    await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def bot_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "点击「打开礼物租赁」进入小程序浏览和租赁礼物。\n"
        "如有问题请联系管理员。"
    )

async def bot_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("无权限")
        return
    url = (WEBAPP_URL or "").rstrip("/") + "/admin"
    await update.message.reply_text(f"后台管理地址：\n{url}\n\n密码：{ADMIN_PASSWORD}")

async def run_bot():
    global bot_app
    if not BOT_TOKEN:
        logger.warning("未设置 BOT_TOKEN，机器人不会启动")
        return
    bot_app = ApplicationBuilder().token(BOT_TOKEN).build()
    bot_app.add_handler(CommandHandler("start", bot_start))
    bot_app.add_handler(CommandHandler("help", bot_help))
    bot_app.add_handler(CommandHandler("admin", bot_admin))
    await bot_app.initialize()
    await bot_app.start()
    await bot_app.updater.start_polling(allowed_updates=Update.ALL_TYPES)
    logger.info("Telegram Bot 已启动")

# ==================== FastAPI ====================
@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    # 启动机器人
    asyncio.create_task(run_bot())
    yield
    # 关闭
    if bot_app:
        await bot_app.updater.stop()
        await bot_app.stop()
        await bot_app.shutdown()

app = FastAPI(title="礼物租赁", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

class GiftOut(BaseModel):
    id: int
    gift_number: str
    name: str
    variant: Optional[str]
    image_url: Optional[str]
    category: str
    price_per_day: float
    min_days: int
    max_days: int
    is_available: bool
    class Config:
        from_attributes = True

class OrderCreate(BaseModel):
    gift_id: int
    days: int
    user_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None

def generate_order_no():
    return datetime.now().strftime("%Y%m%d%H%M%S") + uuid.uuid4().hex[:6].upper()

async def get_or_create_user(session, user_id, username=None, first_name=None):
    result = await session.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        user = User(id=user_id, username=username, first_name=first_name)
        session.add(user)
        await session.commit()
    return user

# ---------- 页面 ----------
@app.get("/", response_class=HTMLResponse)
async def mini_app(request: Request):
    return templates.TemplateResponse("miniapp.html", {"request": request})

@app.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request):
    return templates.TemplateResponse("admin.html", {"request": request})

# ---------- API ----------
@app.get("/api/gifts", response_model=List[GiftOut])
async def list_gifts(q: Optional[str] = None, category: Optional[str] = None,
                     page: int = 1, page_size: int = 30, session: AsyncSession = Depends(get_session)):
    query = select(Gift).where(Gift.is_available == True)
    if q:
        query = query.where(or_(Gift.name.ilike(f"%{q}%"), Gift.gift_number.ilike(f"%{q}%"), Gift.variant.ilike(f"%{q}%")))
    if category and category != "全部":
        query = query.where(Gift.category == category)
    query = query.order_by(Gift.id.desc()).offset((page-1)*page_size).limit(page_size)
    result = await session.execute(query)
    return result.scalars().all()

@app.get("/api/gifts/stats")
async def gifts_stats(session: AsyncSession = Depends(get_session)):
    total = await session.scalar(select(func.count(Gift.id))) or 0
    available = await session.scalar(select(func.count(Gift.id)).where(Gift.is_available == True)) or 0
    return {"total": total, "available": available}

@app.get("/api/gifts/{gift_id}", response_model=GiftOut)
async def get_gift(gift_id: int, session: AsyncSession = Depends(get_session)):
    result = await session.execute(select(Gift).where(Gift.id == gift_id))
    gift = result.scalar_one_or_none()
    if not gift:
        raise HTTPException(404, "不存在")
    return gift

@app.post("/api/orders")
async def create_order(data: OrderCreate, session: AsyncSession = Depends(get_session)):
    result = await session.execute(select(Gift).where(Gift.id == data.gift_id))
    gift = result.scalar_one_or_none()
    if not gift or not gift.is_available:
        raise HTTPException(400, "礼物不可用")
    if data.days < gift.min_days or data.days > gift.max_days:
        raise HTTPException(400, f"天数需在 {gift.min_days}-{gift.max_days} 之间")
    await get_or_create_user(session, data.user_id, data.username, data.first_name)
    total = round(gift.price_per_day * data.days, 4)
    order = Order(order_no=generate_order_no(), user_id=data.user_id, gift_id=gift.id,
                  days=data.days, price_per_day=gift.price_per_day, total_price=total, status="pending")
    session.add(order)
    await session.commit()
    return {"success": True, "order_no": order.order_no, "total_price": total}

@app.get("/api/orders/user/{user_id}")
async def user_orders(user_id: int, session: AsyncSession = Depends(get_session)):
    result = await session.execute(
        select(Order).options(selectinload(Order.gift)).where(Order.user_id == user_id).order_by(Order.created_at.desc())
    )
    orders = result.scalars().all()
    return [{"id": o.id, "order_no": o.order_no, "gift_name": o.gift.name if o.gift else None,
             "gift_number": o.gift.gift_number if o.gift else None, "days": o.days,
             "total_price": o.total_price, "status": o.status,
             "created_at": o.created_at.isoformat()} for o in orders]

# ---------- 后台 API ----------
@app.post("/api/admin/login")
async def admin_login(password: str = Form(...)):
    if password == ADMIN_PASSWORD:
        return {"success": True, "token": "admin_ok"}
    raise HTTPException(401, "密码错误")

@app.get("/api/admin/stats")
async def admin_stats(session: AsyncSession = Depends(get_session)):
    return {
        "gifts": await session.scalar(select(func.count(Gift.id))) or 0,
        "available_gifts": await session.scalar(select(func.count(Gift.id)).where(Gift.is_available == True)) or 0,
        "orders": await session.scalar(select(func.count(Order.id))) or 0,
        "users": await session.scalar(select(func.count(User.id))) or 0,
        "pending_orders": await session.scalar(select(func.count(Order.id)).where(Order.status == "pending")) or 0,
    }

@app.get("/api/admin/gifts")
async def admin_list_gifts(session: AsyncSession = Depends(get_session)):
    result = await session.execute(select(Gift).order_by(Gift.id.desc()).limit(100))
    gifts = result.scalars().all()
    return {"total": len(gifts), "items": [GiftOut.model_validate(g) for g in gifts]}

@app.post("/api/admin/gifts")
async def admin_create_gift(
    gift_number: str = Form(...), name: str = Form(...), variant: Optional[str] = Form(None),
    category: str = Form("全部"), price_per_day: float = Form(0.02),
    min_days: int = Form(3), max_days: int = Form(180), is_available: bool = Form(True),
    image: Optional[UploadFile] = File(None), session: AsyncSession = Depends(get_session)
):
    exists = await session.scalar(select(Gift).where(Gift.gift_number == gift_number))
    if exists:
        raise HTTPException(400, "编号已存在")
    image_url = None
    if image and image.filename:
        ext = Path(image.filename).suffix or ".png"
        filename = f"{uuid.uuid4().hex}{ext}"
        path = STATIC_DIR / "gifts" / filename
        content = await image.read()
        with open(path, "wb") as f:
            f.write(content)
        image_url = f"/static/gifts/{filename}"
    gift = Gift(gift_number=gift_number, name=name, variant=variant, image_url=image_url,
                category=category, price_per_day=price_per_day, min_days=min_days,
                max_days=max_days, is_available=is_available)
    session.add(gift)
    await session.commit()
    await session.refresh(gift)
    return GiftOut.model_validate(gift)

@app.delete("/api/admin/gifts/{gift_id}")
async def admin_delete_gift(gift_id: int, session: AsyncSession = Depends(get_session)):
    result = await session.execute(select(Gift).where(Gift.id == gift_id))
    gift = result.scalar_one_or_none()
    if not gift:
        raise HTTPException(404)
    await session.delete(gift)
    await session.commit()
    return {"success": True}

@app.get("/api/admin/orders")
async def admin_list_orders(status: Optional[str] = None, session: AsyncSession = Depends(get_session)):
    query = select(Order).options(selectinload(Order.gift), selectinload(Order.user)).order_by(Order.created_at.desc()).limit(50)
    if status:
        query = query.where(Order.status == status)
    result = await session.execute(query)
    orders = result.scalars().all()
    return {"items": [{
        "id": o.id, "order_no": o.order_no, "user_id": o.user_id,
        "username": o.user.username if o.user else None,
        "gift_name": o.gift.name if o.gift else None,
        "gift_number": o.gift.gift_number if o.gift else None,
        "days": o.days, "total_price": o.total_price, "status": o.status,
        "created_at": o.created_at.isoformat()
    } for o in orders]}

@app.post("/api/admin/orders/{order_id}/status")
async def admin_update_order_status(order_id: int, status: str = Form(...), session: AsyncSession = Depends(get_session)):
    result = await session.execute(select(Order).where(Order.id == order_id))
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(404)
    order.status = status
    if status == "active" and not order.start_date:
        order.start_date = date.today()
        order.end_date = date.today() + timedelta(days=order.days)
    await session.commit()
    return {"success": True}

# 健康检查（云平台需要）
@app.get("/health")
async def health():
    return {"status": "ok"}

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
