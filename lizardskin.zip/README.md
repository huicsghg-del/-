# 礼物租赁（云部署版）

一个服务同时运行：Telegram Bot + Mini App + 后台管理。

适合用手机部署到 Railway / Render 等平台。

## 手机部署到 Railway（推荐）

### 准备
1. 注册 [Railway](https://railway.app)（可用 GitHub 登录）
2. 准备好你的 Bot Token 和 Telegram 用户 ID

### 步骤
1. 把本项目上传到 GitHub（或用 Railway 直接部署）
2. 在 Railway 新建项目 → Deploy from GitHub
3. 添加环境变量：
   - `BOT_TOKEN` = 你的机器人 Token
   - `ADMIN_IDS` = 你的用户ID（多个用逗号分隔）
   - `ADMIN_PASSWORD` = 后台密码
   - `WEBAPP_URL` = 部署后 Railway 给你的域名（例如 https://xxx.up.railway.app）
4. 部署完成后，把 `WEBAPP_URL` 改成真实地址，重新部署一次
5. 在 Telegram 给机器人发 `/start` 测试

### 后台地址
`https://你的域名/admin`

## 环境变量说明

| 变量 | 必填 | 说明 |
|------|------|------|
| BOT_TOKEN | 是 | Telegram Bot Token |
| ADMIN_IDS | 是 | 管理员 Telegram ID，多个用逗号 |
| ADMIN_PASSWORD | 否 | 后台密码，默认 admin123 |
| WEBAPP_URL | 是 | 你的网站完整地址（https 开头） |
| PORT | 否 | 端口，云平台会自动设置 |

## 本地测试
```bash
export BOT_TOKEN=你的Token
export ADMIN_IDS=你的ID
export WEBAPP_URL=https://你的ngrok地址
python main.py
```
